from analysis_engine.population_analyzer import analyze_population
from analysis_engine.policy_engine import generate_policy_recommendations


def run_pipeline(mode="national", state=None):
    """
    Orchestrates analytics without passing DataFrames.
    Each analyzer is responsible for loading its own data.
    """
    pop_summary = analyze_population(mode=mode, state=state)
    policies = generate_policy_recommendations(pop_summary)

    return pop_summary, policies
