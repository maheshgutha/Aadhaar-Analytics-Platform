from ai_engine.policy_ai import ask

def run_ai_analysis(mode, state):
    summary, intelligence, policy, forecast, warnings = ask("", mode, state)

    return {
        "summary": summary,
        "intelligence": intelligence,
        "policy": policy,
        "forecast": forecast,
        "warnings": warnings
    }
