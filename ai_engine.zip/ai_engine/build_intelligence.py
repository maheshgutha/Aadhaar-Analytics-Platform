import pandas as pd
from pathlib import Path

# Resolve UIDAI project root safely
BASE_DIR = Path(__file__).resolve().parents[1]

RAW_DIR = BASE_DIR / "data" / "raw"
OUT_FILE = BASE_DIR / "data" / "processed" / "monthly_intelligence.csv"


def load_folder(folder: Path) -> pd.DataFrame:
    files = list(folder.glob("*.csv"))
    if not files:
        raise FileNotFoundError(f"No CSV files found in {folder}")

    frames = []
    for f in files:
        try:
            df = pd.read_csv(f)
            frames.append(df)
        except Exception:
            continue

    if not frames:
        raise ValueError(f"All CSV files in {folder} failed to load")

    return pd.concat(frames, ignore_index=True)


def build_monthly_intelligence():
    demo = load_folder(RAW_DIR / "demographic")
    bio = load_folder(RAW_DIR / "biometric")
    enr = load_folder(RAW_DIR / "enrolment")

    # Normalize columns
    for df in (demo, bio, enr):
        df.columns = df.columns.str.lower()
        df["date"] = pd.to_datetime(df["date"], errors="coerce", dayfirst=True)

    # Merge datasets
    data = demo.merge(
        enr,
        on=["date", "state", "district", "pincode"],
        how="outer"
    )
    data = data.merge(
        bio,
        on=["date", "state", "district", "pincode"],
        how="outer"
    )

    # Monthly aggregation
    data["month"] = data["date"].dt.to_period("M")
    monthly = (
        data
        .groupby(["state", "district", "month"], as_index=False)
        .sum(numeric_only=True)
    )

    OUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    monthly.to_csv(OUT_FILE, index=False)

    print(f"✅ Monthly intelligence created at: {OUT_FILE}")


if __name__ == "__main__":
    build_monthly_intelligence()
