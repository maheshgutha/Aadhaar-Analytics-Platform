import pandas as pd
import numpy as np
import joblib
from pathlib import Path

# -------------------------------------------------
# Resolve UIDAI project root safely
# -------------------------------------------------
BASE_DIR = Path(__file__).resolve().parents[1]
MODEL_PATH = BASE_DIR / "ai_engine" / "forecast_models.pkl"
DATA_PATH = BASE_DIR / "data" / "processed" / "monthly_intelligence.csv"


# -------------------------------------------------
# Loaders (NO import-time execution elsewhere)
# -------------------------------------------------
def load_models():
    if not MODEL_PATH.exists():
        return {}
    return joblib.load(MODEL_PATH)


def load_intelligence_df():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Monthly intelligence file not found at: {DATA_PATH}"
        )

    df = pd.read_csv(DATA_PATH)
    df["month"] = pd.to_datetime(df["month"], errors="coerce")

    # Numeric safety
    for col in [
        "age_0_5",
        "age_5_17",
        "age_18_greater",
        "biometric_updates",
        "enrolment_count",
    ]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    # Feature engineering
    df["migration_score"] = df.get("age_5_17", 0) + df.get("age_18_greater", 0)
    df["service_load"] = df.get("age_18_greater", 0)
    df["child_focus"] = df.get("age_0_5", 0) + df.get("age_5_17", 0)

    return df


# -------------------------------------------------
# Forecast helpers
# -------------------------------------------------
def forecast_demand(models, state, district, months=3):
    key = f"{state}|{district}"
    if key not in models:
        return []
    return models[key].forecast(months).tolist()


# -------------------------------------------------
# Core AI Brain
# -------------------------------------------------
def ask(query, mode, state):
    df = load_intelligence_df()
    models = load_models()

    # -------- Resolve National Mode --------
    if mode == "national":
        state = (
            df.groupby("state")["service_load"]
            .sum()
            .idxmax()
        )

    state_df = df[df["state"] == state]
    if state_df.empty:
        return (
            [f"No data available for {state}"],
            [],
            [],
            [],
            ["Insufficient data for analysis"]
        )

    # -------- District Metrics --------
    district_loads = state_df.groupby("district")["service_load"].sum()
    district_migration = state_df.groupby("district")["migration_score"].sum()
    district_child = state_df.groupby("district")["child_focus"].sum()

    top_load_district = district_loads.idxmax()
    top_load_value = district_loads.max()
    total_load = district_loads.sum()
    load_share = (top_load_value / max(total_load, 1)) * 100

    # -------- Derived Indices --------
    mpi = (district_migration / district_loads.replace(0, 1))
    top_migration_district = mpi.idxmax()
    top_child_district = district_child.idxmax()

    # -------- Life-Stage Signals --------
    total_activity = (
        state_df["age_0_5"].sum()
        + state_df["age_5_17"].sum()
        + state_df["age_18_greater"].sum()
    )

    youth_ratio = (
        state_df["age_18_greater"].sum() / max(total_activity, 1)
    )
    child_ratio = (
        state_df["child_focus"].sum() / max(total_activity, 1)
    )

    # -------- Societal Classification --------
    if youth_ratio > 0.60:
        societal_profile = "High workforce mobility state"
    elif child_ratio > 0.30:
        societal_profile = "Education expansion phase"
    else:
        societal_profile = "Stabilizing demographic structure"

    # -------- Risk Tier --------
    if load_share > 35:
        risk = "EXTREME"
    elif load_share > 25:
        risk = "HIGH"
    elif load_share > 15:
        risk = "MODERATE"
    else:
        risk = "LOW"

    # -------- Forecast --------
    forecast = forecast_demand(models, state, top_load_district)

    # ===================== OUTPUT =====================

    summary = [
        f"Region: {state}",
        f"Dominant Service District: {top_load_district} ({int(top_load_value):,} updates)",
        f"Share of State Infrastructure Load: {load_share:.1f}%",
        f"Operational Risk Level: {risk}",
        f"Societal Profile: {societal_profile}",
        f"Service Distribution Pattern: {'Uneven' if load_share > 30 else 'Balanced'}"
    ]

    intelligence = [
        f"Primary Migration Corridor: {top_migration_district}",
        f"Migration pressure highest in {top_migration_district}",
        f"Service stress concentrated in {top_load_district}",
        f"Workforce participation ratio: {youth_ratio:.2f}",
        f"Child enrollment dependency: {child_ratio:.2f}",
        f"Education-driven mobility strongest in {top_child_district}"
    ]

    policy = [
        f"Expand permanent Aadhaar infrastructure in {top_load_district}",
        f"Deploy mobile enrollment units in {top_migration_district}",
        f"Strengthen school-linked enrollment drives in {top_child_district}",
        "Dynamically reallocate operators using Service Stress Index",
        "Introduce seasonal staffing with predictive scheduling"
    ]

    if forecast:
        forecast_list = [
            f"Month {i+1}: Expected update volume ≈ {max(0, int(v))}"
            for i, v in enumerate(forecast)
        ]
    else:
        forecast_list = ["Forecast unavailable due to limited historical data"]

    # -------- Early Warning Engine --------
    warnings = []

    if load_share > 30:
        warnings.append("Critical infrastructure saturation risk")

    if youth_ratio > 0.55:
        warnings.append("High workforce mobility causing service instability")

    if 0.35 < youth_ratio <= 0.55:
        warnings.append("Growing employment-driven migration pressure")

    if child_ratio > 0.30:
        warnings.append("Education-cycle enrollment surge expected")

    if child_ratio < 0.15:
        warnings.append("Aging-population dominance emerging")

    if not warnings:
        warnings.append("System currently operating within stable limits")

    return summary, intelligence, policy, forecast_list, warnings

