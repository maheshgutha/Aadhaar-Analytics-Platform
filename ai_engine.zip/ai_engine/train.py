import pandas as pd
from pathlib import Path
from statsmodels.tsa.holtwinters import ExponentialSmoothing
import joblib

# -------------------------------------------------
# Resolve UIDAI project root safely
# -------------------------------------------------
BASE_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = BASE_DIR / "data" / "processed" / "monthly_intelligence.csv"
MODEL_PATH = BASE_DIR / "ai_engine" / "forecast_models.pkl"


def train_forecast_models():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Monthly intelligence file not found at: {DATA_PATH}"
        )

    df = pd.read_csv(DATA_PATH)
    df["month"] = pd.to_datetime(df["month"].astype(str), errors="coerce")

    models = {}

    for (state, district), group in df.groupby(["state", "district"]):
        if "age_18_greater" not in group.columns:
            continue

        series = (
            group
            .sort_values("month")["age_18_greater"]
            .astype(float)
        )

        # Require minimum data points for stability
        if len(series) < 6:
            continue

        try:
            model = ExponentialSmoothing(
                series,
                trend="add",
                seasonal=None
            )
            fit = model.fit()
            models[f"{state}|{district}"] = fit
        except Exception:
            continue

    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(models, MODEL_PATH)

    print(f"✅ Forecast models trained and saved at: {MODEL_PATH}")


if __name__ == "__main__":
    train_forecast_models()
