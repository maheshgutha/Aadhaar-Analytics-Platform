import pandas as pd
import json
from pathlib import Path

# Resolve UIDAI project root safely
BASE_DIR = Path(__file__).resolve().parents[1]

RAW_DIR = BASE_DIR / "data" / "raw"
OUT_FILE = BASE_DIR / "data" / "processed" / "knowledge.json"


def load_folder(folder: Path) -> pd.DataFrame:
    files = list(folder.glob("*.csv"))
    if not files:
        raise FileNotFoundError(f"No CSV files found in {folder}")

    frames = []
    for f in files:
        try:
            df = pd.read_csv(f)
            frames.append(df)
        except Exception:
            continue

    if not frames:
        raise ValueError(f"All CSV files in {folder} failed to load")

    return pd.concat(frames, ignore_index=True)


def build_knowledge_base():
    demo = load_folder(RAW_DIR / "demographic")
    bio = load_folder(RAW_DIR / "biometric")
    enr = load_folder(RAW_DIR / "enrolment")

    # Normalize columns and dates
    for df in (demo, bio, enr):
        df.columns = df.columns.str.lower()
        df["date"] = pd.to_datetime(df["date"], errors="coerce", dayfirst=True)

    # Merge datasets
    data = demo.merge(
        enr,
        on=["date", "state", "district", "pincode"],
        how="outer"
    )
    data = data.merge(
        bio,
        on=["date", "state", "district", "pincode"],
        how="outer"
    )

    # Aggregate intelligence
    intel = (
        data
        .groupby(["state", "district"], as_index=False)
        .sum(numeric_only=True)
    )

    # Build knowledge dictionary
    knowledge = {}
    for _, r in intel.iterrows():
        key = f"{r['state']} | {r['district']}"
        knowledge[key] = r.to_dict()

    OUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT_FILE, "w", encoding="utf-8") as f:
        json.dump(knowledge, f, indent=2)

    print(f"✅ Knowledge base built at: {OUT_FILE}")


if __name__ == "__main__":
    build_knowledge_base()
