let chart = null;

/* ---------- BASIC SETUP ---------- */
const stateBox = document.getElementById("stateBox");
const panelTitle = document.getElementById("panel-title");
const analyticsPanel = document.getElementById("analytics-panel");

const mode =
  new URLSearchParams(window.location.search).get("mode") || "national";

/* ---------- STATE DROPDOWN ---------- */
if (mode === "state") {
  const states = [
    "Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa",
    "Gujarat","Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala",
    "Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland",
    "Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura",
    "Uttar Pradesh","Uttarakhand","West Bengal",
    "Andaman and Nicobar Islands","Chandigarh",
    "Dadra and Nagar Haveli and Daman and Diu","Delhi",
    "Jammu and Kashmir","Ladakh","Lakshadweep","Puducherry"
  ];

  stateBox.innerHTML =
    `<option value="" disabled selected hidden>Select a State</option>` +
    states.map(s => `<option value="${s}">${s}</option>`).join("");
} else {
  stateBox.style.display = "none";
}

/* ---------- ACTIVE BUTTON ---------- */
function setActiveButton(btn) {
  document.querySelectorAll(".btn-success")
    .forEach(b => b.classList.replace("btn-success", "btn-info"));
  btn.classList.replace("btn-info", "btn-success");
}

/* ---------- VISUALIZATION PANEL ---------- */
function updateVisualization(title) {
  panelTitle.innerText = title;
  analyticsPanel.innerHTML = `<canvas id="chart"></canvas>`;
}

function toggleChartExpand() {
  const chartCol = document.getElementById("chart-column");
  const btn = document.getElementById("expandBtn");

  const expanded = chartCol.classList.toggle("chart-expanded");
  btn.textContent = expanded ? "🗗" : "⛶";

  if (chart) {
    setTimeout(() => chart.resize(), 50);
  }
}

/* ---------- CHART ---------- */
function getShortLabel(name) {
  const map = {
    "Andhra Pradesh": "AP","Arunachal Pradesh": "AR","Assam": "AS","Bihar": "BR",
    "Chhattisgarh": "CG","Goa": "GA","Gujarat": "GJ","Haryana": "HR",
    "Himachal Pradesh": "HP","Jharkhand": "JH","Karnataka": "KA","Kerala": "KL",
    "Madhya Pradesh": "MP","Maharashtra": "MH","Manipur": "MN","Meghalaya": "ML",
    "Mizoram": "MZ","Nagaland": "NL","Odisha": "OD","Punjab": "PB",
    "Rajasthan": "RJ","Sikkim": "SK","Tamil Nadu": "TN","Telangana": "TS",
    "Tripura": "TR","Uttar Pradesh": "UP","Uttarakhand": "UK","West Bengal": "WB"
  };
  return map[name] || name.slice(0, 4).toUpperCase();
}

function drawChart(title, labels, values) {
  const canvas = document.getElementById("chart");
  if (!canvas) return;

  if (chart) chart.destroy();

  const ctx = canvas.getContext("2d");
  const shortLabels = labels.map(getShortLabel);

  const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
  gradient.addColorStop(0, "rgba(37, 99, 235, 0.95)");
  gradient.addColorStop(1, "rgba(37, 99, 235, 0.55)");

  chart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: shortLabels,
      datasets: [{
        data: values,
        backgroundColor: gradient,
        borderColor: "rgba(30, 64, 175, 1)",
        borderWidth: 1,
        borderRadius: 0,
        borderSkipped: false,
        maxBarThickness: 30
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,

      interaction: {
        mode: "index",
        intersect: false
      },

      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            title: items => labels[items[0].dataIndex],
            label: item => `Value: ${item.raw.toLocaleString()}`
          }
        }
      },

      scales: {
        x: {
          title: {
            display: true,
            text: "Region / Category",
            font: { size: 13, weight: "600" }
          },
          grid: { display: false }
        },
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: "Number of Aadhaar Records / Updates",
            font: { size: 13, weight: "600" }
          },
          grid: { color: "rgba(100,116,139,0.25)" }
        }
      }
    }
  });
}

/* ---------- KPI + INSIGHTS ---------- */
function updateDashboardModules(labels, values) {
  const total = values.reduce((a, b) => a + b, 0);
  const max = Math.max(...values);
  const min = Math.min(...values);

  const maxIndex = values.indexOf(max);
  const minIndex = values.indexOf(min);
  const share = (max / total) * 100;

  document.getElementById("kpi-records").innerText = total.toLocaleString();
  document.getElementById("kpi-signal").innerText =
    share > 30 ? "High Concentration" : "Well Distributed";
  document.getElementById("kpi-coverage").innerText =
    `Top region share: ${share.toFixed(1)}%`;

  document.getElementById("insights-list").innerHTML = `
    <li>Total: <strong>${total.toLocaleString()}</strong></li>
    <li>Highest: <strong>${labels[maxIndex]} (${max.toLocaleString()})</strong></li>
    <li>Lowest: <strong>${labels[minIndex]} (${min.toLocaleString()})</strong></li>
    <li>Top region contributes: <strong>${labels[maxIndex]}</strong></li>
  `;
}

/* ---------- DATA LOAD ---------- */
async function loadData(type) {
  if (mode === "state" && !stateBox.value) return;

  const state = mode === "state" ? stateBox.value : "ALL";
  const res = await fetch(`/api/${type}?mode=${mode}&state=${state}`);
  const json = await res.json();

  updateVisualization(type.charAt(0).toUpperCase() + type.slice(1) + " Analysis");
  drawChart(type, json.labels, json.values);
  updateDashboardModules(json.labels, json.values);
}

/* ---------- CONTROL HANDLERS ---------- */
function loadPopulation(btn){ setActiveButton(btn); loadData("population"); }
function loadTrends(btn){ setActiveButton(btn); loadData("trends"); }
function loadAnomalies(btn){ setActiveButton(btn); loadData("anomalies"); }
function loadOperations(btn){ setActiveButton(btn); loadData("operations"); }
function loadMigration(btn){ setActiveButton(btn); loadData("migration"); }
function loadDemographics(btn){ setActiveButton(btn); loadData("demographics"); }
function loadEnrollment(btn){ setActiveButton(btn); loadData("enrollment"); }
function loadBiometric(btn){ setActiveButton(btn); loadData("biometric"); }
function loadDemographic(btn){ setActiveButton(btn); loadData("demographic"); }
function loadAges(btn){
  setActiveButton(btn);
  panelTitle.innerText = "Age-wise Update Distribution";
  loadData("ages");
}

/* ---------- INITIAL LOAD ---------- */
window.addEventListener("DOMContentLoaded", () => {
  document.querySelector(".btn-info")?.click();
});

/* ---------- STATE CHANGE ---------- */
if (mode === "state") {
  stateBox.addEventListener("change", () => {
    document.querySelector(".btn-success")?.click();
  });
}
