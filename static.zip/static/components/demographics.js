export async function loadDemographics() {
    const res = await fetch("/dashboard/demographics");
    const data = await res.json();

    let html = "<h3>Demographics</h3><ul>";
    data.slice(0, 10).forEach(row => {
        html += `<li>${row.state}: 0-5 → ${row.age_0_5}, 5-17 → ${row.age_5_17}</li>`;
    });
    html += "</ul>";

    document.getElementById("demographics-panel").innerHTML = html;
}
