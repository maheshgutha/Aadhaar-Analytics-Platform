export async function loadOperations() {
    const res = await fetch("/dashboard/operations");
    const data = await res.json();
    document.getElementById("operations-panel").innerHTML = "<h3>Operations</h3><p>" + data.status + "</p>";
}
