export async function loadTrends() {
    const res = await fetch("/dashboard/trends");
    const data = await res.json();
    document.getElementById("trends-panel").innerHTML = "<h3>Trends Loaded</h3><pre>" + JSON.stringify(data.slice(0, 5), null, 2) + "</pre>";
}
