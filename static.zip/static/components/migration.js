export async function loadMigration() {
    const res = await fetch("/dashboard/migration");
    const data = await res.json();
    document.getElementById("migration-panel").innerHTML = "<h3>Migration</h3><p>" + data.status + "</p>";
}
