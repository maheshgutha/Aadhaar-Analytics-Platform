export async function loadAnomalies() {
    const res = await fetch("/dashboard/anomalies");
    const data = await res.json();
    document.getElementById("anomalies-panel").innerHTML = "<h3>Anomalies</h3><p>" + data.status + "</p>";
}
