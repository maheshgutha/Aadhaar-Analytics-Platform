export async function loadPopulation() {
    const res = await fetch("/dashboard/population");
    const data = await res.json();

    let html = "<h2>State-wise Population Growth</h2><ul>";
    data.slice(0, 10).forEach(row => {
        html += `<li>${row.state} → ${row.total_population}</li>`;
    });
    html += "</ul>";

    document.getElementById("result-box").innerHTML = html;
}
