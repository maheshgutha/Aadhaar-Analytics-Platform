/* =========================================================
   GLOBAL DOM REFERENCES
========================================================= */
const modeSelect = document.getElementById("mode");
const stateSelect = document.getElementById("state");
const output = document.getElementById("ai-output");


/* =========================================================
   RUN AI ANALYSIS
========================================================= */
async function runAI() {
  const mode = modeSelect.value;
  const state = stateSelect.value;

  // Loading indicator
  output.innerHTML = `
    <div class="d-flex align-items-center text-muted">
      <div class="spinner-border spinner-border-sm me-2" role="status"></div>
      <span>Running AI analysis…</span>
    </div>
  `;

  try {
    const res = await fetch(
      "http://127.0.0.1:5000/api/ai/analysis?mode=" + mode + "&state=" + state
    );

    const data = await res.json();

    if (data.error) {
      output.innerHTML = `
        <div class="alert alert-danger mb-0">
          <strong>AI Error:</strong> ${data.error}
        </div>
      `;
      return;
    }

    // Render AI output 
    output.innerHTML = `
      <div class="ai-report">

        <div class="mb-3">
          <span class="badge bg-primary mb-2">🧠 Strategic Summary</span>
          <ul class="mb-0">
            ${data.summary.map(i => `<li>${i}</li>`).join("")}
          </ul>
        </div>

        <div class="mb-3">
          <span class="badge bg-info mb-2">📊 Intelligence Signals</span>
          <ul class="mb-0">
            ${data.intelligence.map(i => `<li>${i}</li>`).join("")}
          </ul>
        </div>

        <div class="mb-3">
          <span class="badge bg-success mb-2">🏛️ Policy Recommendations</span>
          <ul class="mb-0">
            ${data.policy.map(i => `<li>${i}</li>`).join("")}
          </ul>
        </div>

        <div class="mb-3">
          <span class="badge bg-warning text-dark mb-2">📈 Demand Forecast</span>
          <ul class="mb-0">
            ${data.forecast.map(i => `<li>${i}</li>`).join("")}
          </ul>
        </div>

        <div>
          <span class="badge bg-danger mb-2">🚨 Risk & Early Warnings</span>
          <ul class="mb-0">
            ${data.warnings.map(i => `<li>${i}</li>`).join("")}
          </ul>
        </div>

      </div>
    `;

  } catch (err) {
    output.innerHTML = `
      <div class="alert alert-danger mb-0">
        <strong>AI Engine Error:</strong> Failed to fetch AI response
      </div>
    `;
  }
}


/* =========================================================
   STATE DROPDOWN LOGIC (MODE-DEPENDENT)
========================================================= */
function updateStateOptions() {
  const isNational = modeSelect.value === "national";

  for (const option of stateSelect.options) {
    if (option.value === "") {
      // "Select a State"
      option.hidden = isNational;
      if (!isNational) option.selected = true;

    } else if (option.value === "ALL") {
      // ALL INDIA
      option.hidden = !isNational;
      if (isNational) option.selected = true;

    } else {
      // Actual states
      option.hidden = isNational;
    }
  }
}


/* =========================================================
   INIT
========================================================= */
modeSelect.addEventListener("change", updateStateOptions);
updateStateOptions();
