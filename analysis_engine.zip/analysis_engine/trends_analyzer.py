from analysis_engine.loader import load_data

def analyze_trends(state):
    df = load_data()
    if state != "ALL":
        df = df[df["state"] == state]

    g = df.groupby("district")["age_18_greater"].mean()
    return {"labels": g.index.tolist(), "values": g.values.tolist()}
