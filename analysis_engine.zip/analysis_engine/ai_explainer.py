def explain(metric, data=None):
    if metric == "population":
        return "Population trends indicate regions where infrastructure, housing and public services will be under pressure."

    if metric == "trends":
        return "Trends reveal seasonal enrollment behavior and help forecast staffing and infrastructure demand."

    if metric == "anomalies":
        return "Anomalies highlight abnormal operational patterns requiring immediate investigation."

    if metric == "migration":
        return "Migration patterns reflect employment-driven movement and regional economic shifts."

    if metric == "demographics":
        return "Demographic distribution supports targeted delivery of welfare and public programs."

    return "No explanation available."
