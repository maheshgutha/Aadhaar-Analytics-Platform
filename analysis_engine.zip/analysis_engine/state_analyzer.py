import pandas as pd
from .ai_models import detect_anomalies, cluster_districts

def analyze_state(df, state):
    sdf = df[df["state"].str.lower() == state.lower()].copy()

    if sdf.empty:
        return {
            "state": state,
            "message": "No data available for this state."
        }

    # Clean NaN values
    sdf = sdf.dropna(subset=["enrolment_count", "biometric_updates", "service_stress"])

    # AI models only if enough data
    if len(sdf) > 10:
        sdf = detect_anomalies(sdf)
        sdf = cluster_districts(sdf)
    else:
        sdf["anomaly"] = 0
        sdf["cluster"] = 0

    report = {
        "state": state,
        "avg_enrolment_growth": round(float(sdf["enrol_growth"].mean()), 2),
        "service_stress_index": round(float(sdf["service_stress"].mean()) * 100, 2),
        "anomalies_detected": int((sdf["anomaly"] == -1).sum()),
        "high_risk_districts": list(
            sdf.sort_values("service_stress", ascending=False)["district"].head(5)
        )
    }

    return report
