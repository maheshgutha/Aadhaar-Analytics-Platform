def generate_insights(report):
    insights = []

    if report["service_stress_index"] > 70:
        insights.append("High service stress — immediate infrastructure scaling recommended.")

    if report["anomalies_detected"] > 3:
        insights.append("Significant anomalies detected — possible abnormal demand or data inconsistencies.")

    if report["avg_enrolment_growth"] > 10:
        insights.append("Rapid enrolment growth — future capacity planning required.")

    if not insights:
        insights.append("System performance stable — no immediate action required.")

    return insights
