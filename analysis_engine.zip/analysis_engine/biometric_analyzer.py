import pandas as pd
from pathlib import Path

# Resolve UIDAI/ safely
BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data" / "raw" / "biometric"


def analyze_biometric(mode="national", state=None):
    files = list(DATA_DIR.glob("*.csv"))
    if not files:
        return {}

    frames = []
    for f in files:
        try:
            frames.append(pd.read_csv(f))
        except Exception:
            continue

    if not frames:
        return {}

    df = pd.concat(frames, ignore_index=True)
    df.columns = df.columns.str.lower()

    # detect first numeric column automatically
    numeric_cols = df.select_dtypes(include="number").columns
    if len(numeric_cols) == 0:
        return {}

    value_col = numeric_cols[0]

    if mode == "national":
        result = df.groupby("state")[value_col].sum()
    else:
        df = df[df["state"] == state]
        result = df.groupby("district")[value_col].sum()

    return result.sort_values(ascending=False).to_dict()
