import os
import pandas as pd

BASE_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")
)

DATA_FILE = os.path.join(
    BASE_DIR,
    "data",
    "processed",
    "integrated_master.csv"
)

REQUIRED_COLUMNS = {
    "state",
    "district",
    "age_0_5",
    "age_5_17",
    "age_18_greater"
}

def load_population_df():
    if not os.path.exists(DATA_FILE):
        raise FileNotFoundError(
            f"Processed data file not found at: {DATA_FILE}"
        )

    df = pd.read_csv(DATA_FILE)

    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    for col in ["age_0_5", "age_5_17", "age_18_greater"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    df["population"] = (
        df["age_0_5"] + df["age_5_17"] + df["age_18_greater"]
    )

    return df

def analyze_population(mode="national", state=None):
    df = load_population_df()

    if mode == "national":
        result = df.groupby("state")["population"].sum()
    else:
        result = (
            df[df["state"] == state]
            .groupby("district")["population"]
            .sum()
        )

    return result.sort_values(ascending=False).to_dict()
