import pandas as pd
from pathlib import Path

def load_folder_csv(folder_path: Path):
    all_files = list(folder_path.glob("*.csv"))

    if not all_files:
        raise FileNotFoundError(f"No CSV files found in {folder_path}")

    df_list = []
    for file in all_files:
        df = pd.read_csv(file)
        df_list.append(df)

    return pd.concat(df_list, ignore_index=True)
