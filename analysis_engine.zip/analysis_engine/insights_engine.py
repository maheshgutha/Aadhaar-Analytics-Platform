import pandas as pd
from pathlib import Path

# Resolve UIDAI project root safely
BASE_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = BASE_DIR / "data" / "processed" / "integrated_master.csv"


def load_insight_df():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Processed data file not found at: {DATA_PATH}"
        )

    df = pd.read_csv(DATA_PATH)

    # Ensure required columns exist
    required_cols = {
        "state",
        "district",
        "service_load",
        "migration_score",
        "child_focus"
    }

    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    # Numeric safety
    for col in ["service_load", "migration_score", "child_focus"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    return df


def generate_insights(mode="national", state=None):
    df = load_insight_df()
    insights = []

    if mode == "national":
        top_states = (
            df.groupby("state")["service_load"]
            .sum()
            .sort_values(ascending=False)
            .head(3)
        )
        insights.append(
            f"Highest service demand in {', '.join(top_states.index)}."
        )

        migration = (
            df.groupby("state")["migration_score"]
            .sum()
            .idxmax()
        )
        insights.append(f"Migration pressure strongest in {migration}.")

        child = (
            df.groupby("state")["child_focus"]
            .sum()
            .idxmax()
        )
        insights.append(f"Child enrollment focus increasing in {child}.")

        stability = (
            df.groupby("state")["service_load"]
            .std()
            .sort_values()
            .index[0]
        )
        insights.append(f"Service load most stable in {stability}.")

    else:
        if not state:
            return []

        data = df[df["state"] == state]

        district_pressure = (
            data.groupby("district")["service_load"]
            .sum()
            .idxmax()
        )
        insights.append(
            f"Highest service pressure in {district_pressure} district."
        )

        migration = (
            data.groupby("district")["migration_score"]
            .sum()
            .idxmax()
        )
        insights.append(f"Migration increasing in {migration}.")

        child = (
            data.groupby("district")["child_focus"]
            .sum()
            .idxmax()
        )
        insights.append(f"Child enrollment rising in {child}.")

        stable = (
            data.groupby("district")["service_load"]
            .std()
            .sort_values()
            .index[0]
        )
        insights.append(f"Most stable service district is {stable}.")

    return insights
