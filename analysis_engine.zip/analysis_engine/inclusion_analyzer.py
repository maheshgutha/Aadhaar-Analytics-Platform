import pandas as pd
from pathlib import Path

# Resolve UIDAI/ safely
BASE_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = BASE_DIR / "data" / "processed" / "integrated_master.csv"


def load_demographic_df():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Processed data file not found at: {DATA_PATH}"
        )

    df = pd.read_csv(DATA_PATH)

    # Ensure numeric safety
    for col in ["age_0_5", "age_5_17"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    return df


def analyze_demographics(mode="national", state=None):
    df = load_demographic_df()

    df["inclusion"] = df["age_0_5"] + df["age_5_17"]

    if mode == "national":
        result = df.groupby("state")["inclusion"].sum()
    else:
        result = (
            df[df["state"] == state]
            .groupby("district")["inclusion"]
            .sum()
        )

    return result.sort_values(ascending=False).to_dict()
