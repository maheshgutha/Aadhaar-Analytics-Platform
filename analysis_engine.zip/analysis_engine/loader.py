import pandas as pd
from pathlib import Path

# Resolve UIDAI project root safely
BASE_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = BASE_DIR / "data" / "processed" / "integrated_master.csv"


def load_data():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Processed data file not found at: {DATA_PATH}"
        )

    return pd.read_csv(DATA_PATH)
