import pandas as pd
from pathlib import Path

# Resolve UIDAI/ safely
BASE_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = BASE_DIR / "data" / "processed" / "integrated_master.csv"


def load_anomaly_df():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Processed data file not found at: {DATA_PATH}"
        )

    df = pd.read_csv(DATA_PATH)

    # Ensure numeric safety
    cols = ["age_0_5", "age_5_17", "age_18_greater"]
    for col in cols:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    return df


def analyze_anomalies(mode="national", state=None):
    df = load_anomaly_df()

    df["total"] = (
        df["age_0_5"] + df["age_5_17"] + df["age_18_greater"]
    )

    threshold = df["total"].mean() + 2 * df["total"].std()
    anomalies = df[df["total"] > threshold]

    if mode == "national":
        result = anomalies.groupby("state")["total"].sum()
    else:
        result = (
            anomalies[anomalies["state"] == state]
            .groupby("district")["total"]
            .sum()
        )

    return result.sort_values(ascending=False).to_dict()
