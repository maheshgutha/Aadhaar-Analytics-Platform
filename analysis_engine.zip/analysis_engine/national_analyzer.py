def analyze_india(df):
    result = {}

    result["total_enrolments"] = int(df["enrolment_count"].sum())
    result["total_biometric_updates"] = int(df["biometric_updates"].sum())
    result["avg_service_stress"] = round(float(df["service_stress"].mean()), 3)

    top_states = (
        df.groupby("state")["service_stress"]
        .mean()
        .sort_values(ascending=False)
        .head(6)
    )

    result["top_states"] = top_states.index.tolist()
    result["top_state_scores"] = top_states.values.round(3).tolist()

    return result
