import matplotlib.pyplot as plt 
import os

OUTPUT_DIR = "output/images"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def save_plot(fig, filename):
    path = os.path.join(OUTPUT_DIR, filename)
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path

def india_summary_plots(df):
    paths = []

    # Enrolment Trend
    fig = plt.figure()
    df.groupby("date")["enrolment_count"].sum().plot(title="India Aadhaar Enrolment Trend")
    paths.append(save_plot(fig, "india_enrolment_trend.png"))

    # Biometric Updates Trend
    fig = plt.figure()
    df.groupby("date")["biometric_updates"].sum().plot(title="India Biometric Updates Trend")
    paths.append(save_plot(fig, "india_biometric_updates.png"))

    # State Stress Heatmap
    fig = plt.figure()
    state_stress = df.groupby("state")["service_stress"].mean().sort_values(ascending=False)
    state_stress.plot(kind="bar", title="State Service Stress Index")
    paths.append(save_plot(fig, "state_stress_index.png"))

    return paths
