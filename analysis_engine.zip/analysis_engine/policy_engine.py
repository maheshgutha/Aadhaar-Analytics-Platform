def generate_policy_recommendations(pop_summary):
    recs = []
    for _, row in pop_summary.iterrows():
        if row["net_growth"] < 0:
            recs.append(f"Increase enrollment centers in {row['state']}")
    return recs
