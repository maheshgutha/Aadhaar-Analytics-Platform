import os
import pandas as pd

BASE_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")
)

DATA_FILE = os.path.join(
    BASE_DIR,
    "data",
    "processed",
    "integrated_master.csv"
)

def load_growth_df():
    if not os.path.exists(DATA_FILE):
        raise FileNotFoundError(
            f"Processed data file not found at: {DATA_FILE}"
        )

    return pd.read_csv(DATA_FILE)

def analyze_trends(mode="national", state=None):
    df = load_growth_df()

    # Ensure numeric safety
    for col in ["age_18_greater", "age_5_17", "age_0_5"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    # Growth index logic
    df["growth_index"] = (
        df["age_18_greater"]
        + df["age_5_17"]
        - df["age_0_5"]
    )

    if mode == "national":
        result = df.groupby("state")["growth_index"].sum()
    else:
        result = (
            df[df["state"] == state]
            .groupby("district")["growth_index"]
            .sum()
        )

    return result.sort_values(ascending=False).to_dict()
