import pandas as pd

def build_features(enrol, demo, bio):
    # -------------------------
    # Ensure numeric safety
    # -------------------------
    numeric_map = {
        "enrol": ["age_0_5", "age_5_17", "age_18_greater"],
        "bio": ["bio_age_5_17", "bio_age_17_"],
        "demo": ["demo_age_5_17", "demo_age_17_"]
    }

    for df, cols in zip(
        (enrol, bio, demo),
        (numeric_map["enrol"], numeric_map["bio"], numeric_map["demo"])
    ):
        for col in cols:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    # -------------------------
    # 1️⃣ Aggregate ENROLMENT
    # -------------------------
    enrol["enrolment_count"] = (
        enrol["age_0_5"] + enrol["age_5_17"] + enrol["age_18_greater"]
    )

    enrol_agg = (
        enrol
        .groupby(["state", "district", "date"], as_index=False)
        .agg(enrolment_count=("enrolment_count", "sum"))
    )

    # -------------------------
    # 2️⃣ Aggregate BIOMETRIC
    # -------------------------
    bio["biometric_updates"] = (
        bio["bio_age_5_17"] + bio["bio_age_17_"]
    )

    bio_agg = (
        bio
        .groupby(["state", "district", "date"], as_index=False)
        .agg(biometric_updates=("biometric_updates", "sum"))
    )

    # -------------------------
    # 3️⃣ Aggregate DEMOGRAPHIC
    # -------------------------
    demo["demographic_total"] = (
        demo["demo_age_5_17"] + demo["demo_age_17_"]
    )

    demo_agg = (
        demo
        .groupby(["state", "district", "date"], as_index=False)
        .agg(demographic_total=("demographic_total", "sum"))
    )

    # -------------------------
    # 4️⃣ Merge
    # -------------------------
    df = enrol_agg.merge(
        bio_agg, on=["state", "district", "date"], how="left"
    )
    df = df.merge(
        demo_agg, on=["state", "district", "date"], how="left"
    )

    df.fillna(0, inplace=True)

    # -------------------------
    # 5️⃣ Advanced Features
    # -------------------------
    df.sort_values(["state", "date"], inplace=True)

    df["enrol_growth"] = (
        df.groupby("state")["enrolment_count"]
        .pct_change()
        .fillna(0)
    )

    df["update_pressure"] = (
        df["biometric_updates"] / (df["enrolment_count"] + 1)
    )

    df["service_stress"] = (
        0.6 * df["update_pressure"] + 0.4 * df["enrol_growth"]
    )

    return df
