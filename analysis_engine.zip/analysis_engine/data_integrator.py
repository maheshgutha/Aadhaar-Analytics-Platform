import pandas as pd
from pathlib import Path
from pipeline.loader import load_all_data # type: ignore

# Resolve UIDAI/
BASE_DIR = Path(__file__).resolve().parents[1]
OUT_PATH = BASE_DIR / "data" / "processed" / "integrated_master.csv"


def integrate():
    enrol, demo, bio = load_all_data()

    # Normalize column names
    enrol.columns = enrol.columns.str.lower()
    demo.columns = demo.columns.str.lower()
    bio.columns = bio.columns.str.lower()

    # -------------------------
    # Ensure numeric safety
    # -------------------------
    for df in (enrol, demo, bio):
        for col in df.columns:
            if col not in ("state", "district"):
                df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    # -------------------------
    # Aggregate safely
    # -------------------------
    enrol_sum = enrol.groupby(["state", "district"], as_index=False).agg({
        "age_0_5": "sum",
        "age_5_17": "sum",
        "age_18_greater": "sum"
    })

    demo_sum = demo.groupby(["state", "district"], as_index=False).agg({
        "demo_age_5_17": "sum",
        "demo_age_17_": "sum"
    })

    bio_sum = bio.groupby(["state", "district"], as_index=False).agg({
        "bio_age_5_17": "sum",
        "bio_age_17_": "sum"
    })

    # -------------------------
    # Merge aggregated tables
    # -------------------------
    df = enrol_sum.merge(demo_sum, on=["state", "district"], how="left")
    df = df.merge(bio_sum, on=["state", "district"], how="left")

    df.fillna(0, inplace=True)

    # -------------------------
    # Write output
    # -------------------------
    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT_PATH, index=False)

    print(f"✅ Integrated dataset created at: {OUT_PATH}")


if __name__ == "__main__":
    integrate()
