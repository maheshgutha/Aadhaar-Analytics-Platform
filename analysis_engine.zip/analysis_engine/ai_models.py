from sklearn.ensemble import IsolationForest
from sklearn.cluster import KMeans

def detect_anomalies(df):
    model = IsolationForest(contamination=0.05, random_state=42)
    df["anomaly"] = model.fit_predict(df[["service_stress"]])
    return df

def cluster_districts(df):
    model = KMeans(n_clusters=4, random_state=42)
    df["cluster"] = model.fit_predict(df[["service_stress", "update_pressure"]])
    return df
