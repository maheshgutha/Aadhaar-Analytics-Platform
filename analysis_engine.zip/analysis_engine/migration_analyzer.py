import pandas as pd
from pathlib import Path

# Resolve UIDAI project root safely
BASE_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = BASE_DIR / "data" / "processed" / "integrated_master.csv"


def load_migration_df():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Processed data file not found at: {DATA_PATH}"
        )

    df = pd.read_csv(DATA_PATH)

    # Ensure required columns exist
    required_cols = {
        "state",
        "district",
        "demo_age_17_",
        "bio_age_17_"
    }

    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    # Numeric safety
    for col in ["demo_age_17_", "bio_age_17_"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    return df


def analyze_migration(mode="national", state=None):
    df = load_migration_df()

    df["movement"] = (df["demo_age_17_"] - df["bio_age_17_"]).abs()

    if mode == "national":
        result = df.groupby("state")["movement"].sum()
    else:
        result = (
            df[df["state"] == state]
            .groupby("district")["movement"]
            .sum()
        )

    return result.sort_values(ascending=False).to_dict()
