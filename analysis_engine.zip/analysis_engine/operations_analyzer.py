import pandas as pd
from pathlib import Path

# Resolve UIDAI project root safely
BASE_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = BASE_DIR / "data" / "processed" / "integrated_master.csv"


def load_operations_df():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Processed data file not found at: {DATA_PATH}"
        )

    df = pd.read_csv(DATA_PATH)

    # Ensure required columns exist
    required_cols = {
        "state",
        "district",
        "demo_age_5_17",
        "bio_age_5_17"
    }

    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    # Numeric safety
    for col in ["demo_age_5_17", "bio_age_5_17"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    return df


def analyze_operations(mode="national", state=None):
    df = load_operations_df()

    df["ops"] = df["demo_age_5_17"] + df["bio_age_5_17"]

    if mode == "national":
        result = df.groupby("state")["ops"].sum()
    else:
        result = (
            df[df["state"] == state]
            .groupby("district")["ops"]
            .sum()
        )

    return result.sort_values(ascending=False).to_dict()
