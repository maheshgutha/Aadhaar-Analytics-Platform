import pandas as pd
from pathlib import Path

# Resolve UIDAI/ safely
BASE_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = BASE_DIR / "data" / "processed" / "integrated_master.csv"


def analyze_ages(mode="national", state="ALL"):
    """
    Returns age-wise Aadhaar update distribution.
    Aggregates data from integrated_master.csv
    """

    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Processed data file not found at: {DATA_PATH}"
        )

    # Load CSV ONLY when function is called
    df = pd.read_csv(DATA_PATH)

    # Ensure numeric safety
    age_cols = ["age_0_5", "age_5_17", "age_18_greater"]
    for col in age_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    # --------------------
    # FILTERING
    # --------------------
    if mode == "state" and state != "ALL":
        df = df[df["state"] == state]

    # --------------------
    # AGGREGATION
    # --------------------
    totals = {
        "0–5": int(df["age_0_5"].sum()),
        "6–17": int(df["age_5_17"].sum()),
        "18+": int(df["age_18_greater"].sum())
    }

    return totals
