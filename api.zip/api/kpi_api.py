from flask import Blueprint, request, jsonify
from pathlib import Path
import json

kpi_api = Blueprint("kpi_api", __name__)

# Resolve UIDAI project root safely
BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data" / "states"


@kpi_api.route("/api/kpi")
def get_kpi():
    mode = request.args.get("mode", "national")
    state = request.args.get("state", "ALL")

    try:
        total = 0
        enrolled = 0

        if not DATA_DIR.exists():
            raise FileNotFoundError(f"State KPI directory not found at: {DATA_DIR}")

        if mode == "national":
            # 🔹 Aggregate all states
            for file in DATA_DIR.glob("*.json"):
                with open(file, "r", encoding="utf-8") as f:
                    data = json.load(f)

                total += int(data.get("total_population", 0))
                enrolled += int(data.get("enrolled", 0))

        else:
            # 🔹 Single state
            path = DATA_DIR / f"{state}.json"
            if not path.exists():
                raise FileNotFoundError(f"KPI file not found for state: {state}")

            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)

            total = int(data.get("total_population", 0))
            enrolled = int(data.get("enrolled", 0))

        coverage = round((enrolled / total) * 100, 2) if total else 0
        signal = "Full Saturation" if coverage >= 95 else "Partial Coverage"

        return jsonify({
            "records": f"{total:,}",
            "coverage": coverage,
            "signal": signal
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500
