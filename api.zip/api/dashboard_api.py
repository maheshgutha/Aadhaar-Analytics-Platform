from flask import Blueprint, jsonify
from analysis_engine.loader import load_data

dashboard_api = Blueprint("dashboard_api", __name__, url_prefix="/dashboard")

@dashboard_api.route("/population")
def population_dashboard():
    df = load_data()

    growth = df.groupby("state")[["age_0_5", "age_5_17", "age_18_greater"]].sum()
    growth["total_population"] = growth.sum(axis=1)

    return jsonify(growth.reset_index().to_dict(orient="records"))


@dashboard_api.route("/trends")
def trends_dashboard():
    df = load_data()
    return jsonify(df.sample(100).to_dict(orient="records"))


@dashboard_api.route("/anomalies")
def anomalies_dashboard():
    return jsonify({"status": "No critical anomalies detected"})


@dashboard_api.route("/operations")
def operations_dashboard():
    return jsonify({"status": "Operations within normal capacity"})


@dashboard_api.route("/migration")
def migration_dashboard():
    return jsonify({"status": "High migration observed in urban centers"})


@dashboard_api.route("/demographics")
def demographics_dashboard():
    df = load_data()
    return jsonify(df.groupby("state")[["age_0_5", "age_5_17"]].sum().reset_index().to_dict(orient="records"))
