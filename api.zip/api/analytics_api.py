from flask import Blueprint, jsonify, request

# Core analyzers
from analysis_engine.population_analyzer import analyze_population
from analysis_engine.growth_trend_analyzer import analyze_trends
from analysis_engine.anomaly_detector import analyze_anomalies
from analysis_engine.operations_analyzer import analyze_operations
from analysis_engine.migration_analyzer import analyze_migration
from analysis_engine.inclusion_analyzer import analyze_demographics

# New dataset analyzers
from analysis_engine.enrollment_analyzer import analyze_enrollment
from analysis_engine.biometric_analyzer import analyze_biometric
from analysis_engine.demographic_analyzer import analyze_demographic
from analysis_engine.insights_engine import generate_insights

# Age analyzer
from analysis_engine.age_analyzer import analyze_ages

analytics_api = Blueprint("analytics_api", __name__)

# ---------- Core Dashboard APIs ----------

@analytics_api.route("/api/population")
def population():
    mode = request.args.get("mode", "national")
    state = request.args.get("state", "ALL")
    data = analyze_population(mode, state)
    return jsonify({"labels": list(data.keys()), "values": list(data.values())})

@analytics_api.route("/api/trends")
def trends():
    mode = request.args.get("mode", "national")
    state = request.args.get("state", "ALL")
    data = analyze_trends(mode, state)
    return jsonify({"labels": list(data.keys()), "values": list(data.values())})

@analytics_api.route("/api/anomalies")
def anomalies():
    mode = request.args.get("mode", "national")
    state = request.args.get("state", "ALL")
    data = analyze_anomalies(mode, state)
    return jsonify({"labels": list(data.keys()), "values": list(data.values())})

@analytics_api.route("/api/operations")
def operations():
    mode = request.args.get("mode", "national")
    state = request.args.get("state", "ALL")
    data = analyze_operations(mode, state)
    return jsonify({"labels": list(data.keys()), "values": list(data.values())})

@analytics_api.route("/api/migration")
def migration():
    mode = request.args.get("mode", "national")
    state = request.args.get("state", "ALL")
    data = analyze_migration(mode, state)
    return jsonify({"labels": list(data.keys()), "values": list(data.values())})

@analytics_api.route("/api/demographics")
def demographics():
    mode = request.args.get("mode", "national")
    state = request.args.get("state", "ALL")
    data = analyze_demographics(mode, state)
    return jsonify({"labels": list(data.keys()), "values": list(data.values())})

# ---------- Dataset-Specific APIs ----------

@analytics_api.route("/api/enrollment")
def enrollment():
    mode = request.args.get("mode", "national")
    state = request.args.get("state", "ALL")
    data = analyze_enrollment(mode, state)
    return jsonify({"labels": list(data.keys()), "values": list(data.values())})

@analytics_api.route("/api/biometric")
def biometric():
    mode = request.args.get("mode", "national")
    state = request.args.get("state", "ALL")
    data = analyze_biometric(mode, state)
    return jsonify({"labels": list(data.keys()), "values": list(data.values())})

@analytics_api.route("/api/demographic")
def demographic():
    mode = request.args.get("mode", "national")
    state = request.args.get("state", "ALL")
    data = analyze_demographic(mode, state)
    return jsonify({"labels": list(data.keys()), "values": list(data.values())})
@analytics_api.route("/insights")
def insights_api():
    mode = request.args.get("mode", "national")
    state = request.args.get("state", "ALL")

    insights = generate_insights(mode, state)
    return jsonify(insights=insights)

# ---------- Age-wise Analysis API ----------

@analytics_api.route("/api/ages")
def ages():
    mode = request.args.get("mode", "national")
    state = request.args.get("state", "ALL")

    data = analyze_ages(mode, state)

    return jsonify({
        "labels": list(data.keys()),
        "values": list(data.values())
    })
