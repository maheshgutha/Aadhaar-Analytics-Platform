from flask import Blueprint, jsonify, request
from ai_engine.ai import run_ai_analysis

ai_api = Blueprint("ai_api", __name__)

@ai_api.route("/api/ai/analysis")
def ai_analysis():
    try:
        mode = request.args.get("mode", "national")
        state = request.args.get("state", "ALL")

        result = run_ai_analysis(mode, state)

        return jsonify(result)

    except Exception as e:
        print("AI ERROR:", e)
        return jsonify({"error": str(e)}), 500
